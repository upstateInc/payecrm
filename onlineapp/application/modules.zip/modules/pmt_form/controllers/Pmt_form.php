<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pmt_form extends MX_Controller {

	public function __construct() {
		parent::__construct();
		
		$this->load->helper(array('url','form'));
		$this->load->driver('session');
		$this->load->database();
		$this->load->model(array('Common_model'));
		$this->load->library(array('session','form_validation','email'));
		date_default_timezone_set('America/New_York');
		
		
	}
	
	
		public function business()
	{
		$sid=$_GET['signupid'];
	       $this->load->view("template/header");
      $data['resultarray']=$this->Common_model->GetAllWhere('business',array('userId'=>$sid));
		   $this->load->view("business",$data);
          $this->load->view("template/footer");
	
	
	
	}
	
		public function billing()
	{
		$sid=$_GET['signupid'];
	       $this->load->view("template/header");	
  $data['resultarray']=$this->Common_model->GetAllWhere('billing',array('userId'=>$sid));		   
		   $this->load->view("billing",$data);
          $this->load->view("template/footer");
	
	
	
	}
	
	
		public function document()
	{
		$sid=$_GET['signupid'];
	       $this->load->view("template/header");
		    $data['resultarray']=$this->Common_model->GetAllWhere('billing',array('userId'=>$sid));	
		   $this->load->view("document",$data);
          $this->load->view("template/footer");
	
	
	
	}
	
	
	public function complete()
	{
		$sid=$_GET['signupid'];
	       $this->load->view("template/header");
		    $data['resultarray']=$this->Common_model->GetAllWhere('user',array('id'=>$sid));	
		   $this->load->view("complete",$data);
          $this->load->view("template/footer");
	
	
	
	}
	
	
		
	public function savedocument()
	{
	        $date=date('Y-m-d h:i:s');
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'docx|txt|pdf|doc';
		$config['max_size']	= '100000';
		$config['max_width']  = '1024';
		$config['max_height']  = '768';
		$this->load->library('upload',$config);
		if ($this->upload->do_upload('file'))
		{
		if($this->session->userdata('docno')!=""){	
		$no=$this->session->userdata('docno')+1;
		$this->session->set_userdata('docno',$no);	
		}
		else
		$this->session->set_userdata('docno',1);
	    
		$docno=$this->session->userdata('docno');
		$data = $this->upload->data();
		$name=$data['file_name'];
	     $sid=$this->input->post('sid');
		$doc=$name;
		$userdata=array("doc$docno"=>$doc);
		$this->Common_model->updwhere('billing',array('userId'=>$sid),$userdata);
		
		$this->Common_model->updwhere('user',array('id'=>$sid),array('update'=>$date));
		
		redirect("pmt-form/document?signupid=$sid");
		
		
    }		
	}
	public function savebusiness()
	{
	        $date=date('Y-m-d h:i:s');
		$sid=$this->input->post('sid');
		$businessName=$this->input->post('businessName');
		$dbaName=$this->input->post('dbaName');
		$businessType=$this->input->post('businessType');
		$federalTaxIdTemp=$this->input->post('federalTaxIdTemp');
		$incorporatedStateTemp=$this->input->post('incorporatedStateTemp');
		$websiteAddress=$this->input->post('websiteAddress');
		$businessStreetAddress=$this->input->post('businessStreetAddress');
		$businessCity=$this->input->post('businessCity');
		$businessStateTemp=$this->input->post('businessStateTemp');
		$businessZip=$this->input->post('businessZip');
		$ownershipFirstName=$this->input->post('ownershipFirstName');
		
		$ownershipLastName=$this->input->post('ownershipLastName');
		
		
		$ownership2FirstName=$this->input->post('ownership2FirstName');
		$ownership2LastName=$this->input->post('ownership2LastName');
		
		
		$ownershipHomePhone=$this->input->post('ownershipHomePhone');
		$ownership2HomePhone=$this->input->post('ownership2HomePhone');
		$ownershipEmail=$this->input->post('ownershipEmail');
		
		$ownershipEmail2=$this->input->post('ownershipEmail2');
		
		$ownershipDL=$this->input->post('ownershipDL');
		
		$userdata=array('userId'=>$sid,'businessName'=>$businessName,'tradeName'=>$dbaName,'businessType'=>$businessType,'taxId'=>$federalTaxIdTemp,'corpState'=>$incorporatedStateTemp,'websiteUrl'=>$websiteAddress,'street'=>$businessStreetAddress,'city'=>$businessCity,'state'=>$businessStateTemp,'zip'=>$businessZip,'ownerFName1'=>$ownershipFirstName,'ownerLName1'=>$ownershipLastName,'ownerFName2'=>$ownership2FirstName,'ownerLName2'=>$ownership2LastName,'workPhone'=>$ownershipHomePhone,'mobPhone'=>$ownership2HomePhone,'email'=>$ownershipEmail,'email2'=>$ownershipEmail2,'drLicense'=>$ownershipDL);
	     $this->Common_model->delrec('business',array('userId'=>$sid));
		$insid=$this->Common_model->addrec('business',$userdata);
		
		$this->Common_model->updwhere('user',array('id'=>$sid),array('update'=>$date));
		redirect("pmt-form/billing?signupid=$sid");
		
	}
	
	
	
	
	
	public function savebilling()
	{
	        $date=date('Y-m-d h:i:s');
		$sid=$this->input->post('sid');
		$nameOfPrimaryContact1=$this->input->post('nameOfPrimaryContact1');
		$nameOfPrimaryContact2=$this->input->post('nameOfPrimaryContact2');
		
		
		
		
		$ownershipTitle=$this->input->post('ownershipTitle');
		$primaryCellPhoneTemp=$this->input->post('primaryCellPhoneTemp');
		$businessEmail=$this->input->post('businessEmail');
		$bankName=$this->input->post('bankName');
		$transitRoutingNoTemp=$this->input->post('transitRoutingNoTemp');
		$accountNo=$this->input->post('accountNo');
	     $this->Common_model->delrec('billing',array('userId'=>$sid));
		$userdata=array('userId'=>$sid,'name1'=>$nameOfPrimaryContact1,'name2'=>$nameOfPrimaryContact2,'title'=>$ownershipTitle,
		'phone'=>$primaryCellPhoneTemp,'email'=>$businessEmail,'bankName'=>$bankName,
		'routingNo'=>$transitRoutingNoTemp,'accountNo'=>$accountNo);
		$insid=$this->Common_model->addrec('billing',$userdata);
		
		$this->Common_model->updwhere('user',array('id'=>$sid),array('update'=>$date));
		redirect("pmt-form/document?signupid=$sid");
		
	}
	
	

	
}