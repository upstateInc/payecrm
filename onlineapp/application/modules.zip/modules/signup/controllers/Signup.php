<?php error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends MX_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->helper('form','url');
		$this->load->driver('session');
		$this->load->model(array('Common_model'));
		$this->load->database();
		$this->load->library(array('session','form_validation','email'));
		date_default_timezone_set('America/New_York');
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		/*if($_SESSION['loggedInEmail'])
		{
		$email=$_SESSION['loggedInEmail'];
		}*/
		$this->load->view("template/header");
		 $this->load->view("signup");
		  $this->load->view("template/footer");
		  

	}
	
	
	
	public function savebasic()
	{
		$date=date('Y-m-d h:i:s A');
		
		$fullName=$this->input->post('firstName')." ".$this->input->post('lastName');
		$primaryCellPhone=$this->input->post('primaryCellPhone');
		$email=$this->input->post('email');
		if($this->session->userdata('loggedInEmail'))
		$lie=$this->session->userdata('loggedInEmail');
		else
		$lie=$email;
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email','Email address','trim|is_unique[user.email]');
		if($this->form_validation->run()==true){
		
		$PASSWORD=$this->input->post('user_pass');
		$userdata=array('name'=>$fullName,'email'=>$email,'phone'=>$primaryCellPhone,'password'=>$PASSWORD,'date'=>$date,'loggedInEmail'=>$lie);
		$idd=$this->Common_model->addrec('user',$userdata);
		$this->session->set_userdata($userdata);
        redirect("signup/business?signupid=$idd");
		}
		else
		{
		redirect("signup/?registeredId=$email");	
		}
	
	}
	
	
	
	
	
	
	public function saveform()
	{
		$sid=$this->input->post('sid');
		$company=$this->input->post('company');
		$locationTimezoneTemp=$this->input->post('locationTimezoneTemp');
		$potentialType=$this->input->post('potentialType');
		$industryId=$this->input->post('industryId');
		$freeTrialOffer=$this->input->post('freeTrialOffer');
		
		$userdata=array('organization'=>$company,'location'=>$locationTimezoneTemp,'service'=>$potentialType,'industry'=>$industryId,'freetrial'=>$freeTrialOffer);
		$this->Common_model->updwhere('user',array('id'=>$sid),$userdata);
		redirect("pmt-form/business?signupid=$sid");
	}
	
	
	
	public function deletedoc()
	{
		$sid=$this->session->userdata('id');
		$doc=$this->input->get('doc');
		$tmp=explode('_@',$doc);
		$no=$tmp[0];
		$this->Common_model->updwhere('billing',array('userId'=>$sid),array('doc'.$no=>""));
		redirect("pmt-form/document?signupid=$sid");
	}
	
	
	
	
	
	
	
	public function business()
	{
		/*if($_SESSION['loggedInEmail'])
		{
		$email=$_SESSION['loggedInEmail'];
		}*/
		$this->load->view("template/header");
		 $this->load->view("shortform");
		  $this->load->view("template/footer");
		  

	}
	
	
	
	
}
