 <?php error_reporting(0); ?>
 
 
 <section class="layout">
<style>
 #form-doc-upload.upload-docs div.upload-docs-div.upload-docs-complete {
    color:#67A2C8 !important;
    background-color: #fff !important;
    
   
}


#form-doc-upload.upload-docs div.upload-docs-div {
    width: 100% !important;
  height:130px !important;
    display: inline-block;
    float: center !important;
    text-align:center;
    background:url('');
    background-repeat: no-repeat;
    padding-bottom: 4px !important;
    font-size: 1.3em !important;
    font-weight: normal!important;
    border: 2px solid #e3e6f3;
    border-radius:15px;
}
 </style>
            <!-- main content -->
            <section class="main-content">

                <!-- content wrapper -->
                <div class="content-wrap">     

	<div class="wrapper">
		<div class="row">
			<div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3 col-md-10 col-md-offset-1">
					<h3 class="text-center">PayeHub Online Application Form</h3>
					<h5 class="text-center">Upload your documents here.</h5>
					<br>
					<div id="wizard" class="wizard">
					    <ul class="steps">
					        		<li data-target="#step1" class="">
					        		<span class="badge bg-info"></span>Business/Onwer Info
					        		</li><li data-target="#step2" class="">
					        		<span class="badge bg-info"></span>Billing Information
					        		</li><li data-target="#step4" class="active">
					        		<span class="badge bg-info"></span>Documentation
					        		</li><li data-target="#step5" class="">
					        		<span class="badge bg-info"></span>Completed
					    </li></ul>
				    
					  <div class="actions btn-group">
					        <a class="btn btn-default btn-sm btn-next" href="<?php echo base_url();?>pmt-form/billing?signupid=<?php echo $this->input->get('signupid');?>">
					            <!--<i class="fa fa-angle-left"></i> --><<
					        </a>
					        
					        <a class="btn btn-default btn-sm btn-next" href="<?php echo base_url();?>pmt-form/complete?signupid=<?php echo $this->input->get('signupid');?>">
					           <!-- <i class="fa fa-angle-right"></i> -->>>
					        </a>
					    </div>
					</div>





<script type="text/javascript">
					merchantFormLocked = false;
</script>
<div class="merchantform phub-merchant-form " data-ng-app="phubapp">
	<div data-ng-controller="MerchantFormController" class="ng-scope">





<div class="panel">
	<!--<div class="panel-body text-center">
		<h4>Please download the attached doc file, fill out, and upload it using the form below.</h4>
		
		<a class="btn btn-success mb20" target="_blank" href="">Download Doc</a>
		<hr>
	</div> -->
 
	<div class="panel-body text-center">
		<form id="form-doc-upload" class="clearfix upload-docs phub-merchant-form-na ng-pristine ng-valid" method="post" enctype="multipart/form-data" action="<?php echo base_url();?>pmt-form/savedocument">
		     	 <div class="col-md-4 col-sm-12">     
		      		<div data-doctype="Voided Check And CC" class="upload-docs-div thumbnail drophandler upload-docs-complete dropzone clearfix">
		            	Drag &amp; Drop or Click Here to Upload Your Signed Voided Check And CC Document<div class="dz-default dz-message"></div>
		      		</div>
		      	</div>

      				
			<div id="file-upload-progress" class="file-upload-progress"><p>100%</p><span></span></div>
			<div data-ng-hide="1==1" class="ng-hide">
			   <input name="sid" value="<?php echo $_GET['signupid'];?>" type="hidden">
				<input id="uploaddocs-doctype-elm" name="docType" value="Bank Statement" type="hidden">
				<input id="uploaddocs-file-elm" name="file" type="FILE">
				<input name="step" value="step4" class="phub-merchant-form-na" type="hidden">
			 	<input name="merchantFormId" value="257112" class="phub-merchant-form-na" type="hidden">
        		<input name="agentId" class="phub-merchant-form-na" value="0001" type="hidden">
				<input id="uploaddocs-submit-elm" name="submit" value="Upload" type="submit">
			</div>
		</form>
	</div>
</div>

	<div class="panel">
		<div class="panel-body">
			<h3>Uploaded Documents</h3>
			<table class="table table-striped table-hover uploaded-docs">
					<tbody>
					<?php
					
					   for($i=1;$i<=5;$i++){
					if($resultarray[0]["doc$i"]!="") {  
					?>
					<tr>
						<td><i><?php echo $i;?>.</i></td><td><strong><?php echo $resultarray[0]["doc$i"];?></strong></td><td class="uploaded-doc-type">Voided Check And CC</td><td><a href="<?php echo base_url().'signup/deletedoc?doc='.$i."_@".$resultarray[0]["doc$i"];?>"><i class="fa fa-times" aria-hidden="true"></i></a> </td>
					</tr>
					   <?php } }?>
					
    		</tbody></table>
    	</div>
    </div>



 <form role="form" name="phubfrm" class="phub-merchant-form ng-pristine ng-valid" method="post" action="<?php echo base_url();?>pmt-form/complete?signupid=<?php echo $_GET['signupid'];?>" novalidate="" data-ng-class="{'form-submitted':submitted}">
	<input name="merchantFormId" class="phub-merchant-form-na" value="257112" type="hidden">
	<input name="step" class="phub-merchant-form-na" value="step5" type="hidden">
	<input class="btn btn-success btn-lg btn-block phub-merchant-form-na" value="Complete" type="submit">
</form>



<script language="javascript" type="text/javascript">
	jQuery(function(){
		var jUploadDivs = jQuery(".upload-docs-div");
		var jUploadDocForm = jQuery("#form-doc-upload");
		var jUploadDocType = jQuery("#uploaddocs-doctype-elm");
		var jUploadDocFile = jQuery("#uploaddocs-file-elm");
		var jUploadDocSubmit = jQuery("#uploaddocs-submit-elm");
		var jUploadDocProgress = jQuery("#file-upload-progress");
		var jUploadDocProgressPer = jUploadDocProgress.children("p");
		var jUploadDocProgressSpan = jUploadDocProgress.children("span");
		var fileUploadMuteX = false;
		jUploadDivs.on("click",function(e){
			e.preventDefault();
			console.log(this.getAttribute("id"));
			jUploadDocType.val(this.getAttribute("data-doctype"));
			jUploadDocFile.trigger('click');
		});

		jUploadDocFile.on("change",function(e){
			e.preventDefault();
			console.log("File status:" + jUploadDocFile.val());
			if(jUploadDocFile.val()){
				jUploadDocSubmit.trigger('click');
			}else{
				console.log("No File to upload");
			}
		});
		
		var updateProgressBar = function(percent){
			jUploadDocProgressPer.html(percent + "%");
		    jUploadDocProgressSpan.width(percent + "%");
		}
		window.updateProgressBar = updateProgressBar;
		
		jUploadDivs.bind('fileDropped', function(e, payload){
			if(!fileUploadMuteX){
				fileUploadMuteX = true;
				console.log("fileDropped event triggered",payload,e);
				var files = payload && payload.files ? payload.files : null;
				var obj = payload && payload.obj ? payload.obj : null;
				
				if(obj){
					jUploadDocType.val(obj.getAttribute("data-doctype"));
				}
				
				var fd = new FormData();
				for (var i = 0; i < files.length; i++){
			        
			        fd.append('file', files[i], files[i].name);
			 		console.log("Added file with name : " + files[i].name);
			        //var status = new createStatusbar(obj); //Using this we can set progress.
			        //status.setFileNameSize(files[i].name,files[i].size);
			        //sendFileToServer(fd,status);
				 
				}
				
				var formArr = jUploadDocForm.serializeArray();
				if(formArr && formArr.length > 0){
					for(var i = 0; i < formArr.length; i++){
						fd.append(formArr[i]["name"],formArr[i]["value"]);
						console.log("Added field [" + formArr[i]["name"] + ":" + formArr[i]["value"] + "]");
					}
				}
				window.jUploadDocProgress = jUploadDocProgress;
				jUploadDocProgress.show();
				
				jQuery.ajax({
					xhr: function() {
			            var xhrobj = jQuery.ajaxSettings.xhr();
			            if (xhrobj.upload) {
			                    xhrobj.upload.addEventListener('progress', function(event) {
			                        var percent = 0;
			                        var position = event.loaded || event.position;
			                        var total = event.total;
			                        if (event.lengthComputable) {
			                            percent = Math.ceil(position / total * 100);
			                        }
			                        //Set progress
			                        updateProgressBar(percent);
			                        console.log("Percent:",percent);
			                    }, false);
			                }
			            return xhrobj;
			        },
				  url: jUploadDocForm.attr("action"),
				  type: "POST",
				  data: fd,
				  processData: false,  // tell jQuery not to process the data
				  contentType: false,   // tell jQuery not to set contentType
				  cache: false,
	        	  success: function(data){
	        	  		updateProgressBar("100");
	        	  		jUploadDocProgress.hide();
	            		window.location=window.location;//.reload(false);
	            		fileUploadMuteX = false;         
	        	  },
	        	  error:function(data){
	        	  	updateProgressBar("0");
	        	  	jUploadDocProgress.hide();
	        	  	alert("Error in uploading file " + data);
	        	  	fileUploadMuteX = false;
	        	  }
	        	  
				});
			}else{
				alert("File upload in progress...");
			}
			
		})
		
		
	});
	
</script>	</div>
</div>    				<div class="clear"></div>			
                            
                    <!-- /inner content wrapper -->
 